
#include "mp3_header.h"
#include<string.h>
#include<stdio.h>
#include"ui.h"
#include"mp3_view.h"
#include"mp3_edit.h"
void view(struct MP3 *mp3,int argc, char *argv[])
{
    //reading mp3 and storing in a orginal file pointer
    mp3->org_mp3_fptr=fopen(argv[2],"rb"); 

    if(mp3->org_mp3_fptr == NULL)
    {
        perror(RED"ERROR " RESET);
        return;
    }

    char mp3_identifier[4]="ID3"; //buff
    char str[4]; //temporary string 

    //reading first 3 bytes of data for ID3 +1 byte for '\0'
    fread(str,3,1,mp3->org_mp3_fptr); 
    str[3]='\0'; //accessing '\0' manually to print safely or to avoid confusion

    //checking if audio file is MP3 or not 
    if(!(strcmp(str,mp3_identifier))) 
    {
        printf(GREEN"Audio is MP3 file\n" RESET);
    }
    else
    {
        printf(RED"Audio is not MP3 file\n" RESET);
        fclose(mp3->org_mp3_fptr);
        return;
    }

    /* it will skip current position upto 7 bytes of header
     because no need with 7 bytes so ignore */
    fseek(mp3->org_mp3_fptr,7,SEEK_CUR);

    //content frame tags
    char TAG[5]; 

    /*read 4  bytes for tags from org fptr 
    and print the content of each tag until the end of file */
    while(fread(TAG,4,1,mp3->org_mp3_fptr) == 1)
    {
        /* accessing '\0' manually to print safely or to avoid confusion */
        TAG[4]='\0'; 
        /* to stop unwanted frames bcoz we need only 6 tags 
        (TIT2,TPE1,TALB,TYER,TCON,COMM)& if any other tag comes we'll break loop */
        if(strcmp(TAG,"TIT2")!=0 &&
        strcmp(TAG,"TPE1")!=0 &&
        strcmp(TAG,"TALB")!=0 &&
        strcmp(TAG,"TYER")!=0 &&
        strcmp(TAG,"TCON")!=0 &&
        strcmp(TAG,"COMM")!=0)
        {
            break;
        }
    
        int content_size;
        /* read 4 bytes for size */
        fread(&content_size,4,1,mp3->org_mp3_fptr);  

        //convert big endian to little endian
        toggle_endianess(mp3,&content_size);

        fseek(mp3->org_mp3_fptr,2,SEEK_CUR);//2 bytes from flag , 1byte from null of frame content 

        tag_to_name(TAG);

        print_tag_data(mp3->org_mp3_fptr,&content_size);
        
    }
    fclose(mp3->org_mp3_fptr);
}
void toggle_endianess(struct MP3 *mp3,int *content_size) 
{
    char temp;
    char *ptr=(char*)content_size;
    for(int i=0;i<sizeof(int)/2;i++)
    {
        temp=ptr[i];
       ptr[i]=ptr[4-i-1];
       ptr[4-i-1]=temp;
    }

}
void tag_to_name(char *TAG)
{

    if((strcmp(TAG,"TPE1")) == 0)
    {
        printf(ORANGE"Artist Name -" RESET);
    }
    else if((strcmp(TAG,"TIT2")) == 0)
    {
        printf(BLUE"Title Name -" RESET);
    }
    else if((strcmp(TAG,"TALB")) == 0)
    {
        printf(YELLOW"Album -" RESET);
    }
    else if((strcmp(TAG,"TYER")) == 0)
    {
        printf(PINK"Year -" RESET);
    }
    else if((strcmp(TAG,"TCON")) == 0)
    {
        printf(CYAN"Content Type -" RESET);
    }
    else if((strcmp(TAG,"COMM")) == 0)
    {
        printf(PURPLE"Comment -" RESET);
    }
}

    void print_tag_data(FILE *org_mp3_fptr,int *content_size)
{
    char ch;

    /* skip encoding byte */

    fgetc(org_mp3_fptr);

    for(int i = 0; i < (*content_size) - 1; i++)
    {
        ch = fgetc(org_mp3_fptr);

        if(ch == '\0')
        {
            break;
        }

        putchar(ch);
    }

    printf("\n");
}

