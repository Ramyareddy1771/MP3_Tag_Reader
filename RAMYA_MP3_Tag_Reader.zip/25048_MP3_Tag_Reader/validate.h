#ifndef VALIDATE_H

#include<stdio.h>
#include"mp3_header.h"
#include"mp3_edit.h"
#include"mp3_view.h"

void validate_cla(int argc, char *argv[], struct MP3 *mp3);

#endif