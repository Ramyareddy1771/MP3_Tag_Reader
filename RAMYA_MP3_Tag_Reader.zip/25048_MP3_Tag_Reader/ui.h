//to add colours for user interface
#ifndef ui_h
#define ui_h
#define RESET  "\033[0m"
#define PINK   "\033[35m"
#define ORANGE "\033[38;5;208m"
#define BLUE   "\033[34m"
#define GREEN  "\033[32m"
#define RED    "\033[31m"
#define YELLOW "\033[33m"
#define CYAN   "\033[36m"
#define PURPLE "\033[38;5;141m"
#endif
