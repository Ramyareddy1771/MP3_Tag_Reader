#ifndef mp3_view_h
#define mp3_view_h
#include"mp3_edit.h"
#include"validate.h"
void view(struct MP3 *mp3,int argc, char *argv[]);
void toggle_endianess(struct MP3 *mp3,int *content_size);
void tag_to_name(char *TAG);
void print_tag_data(FILE *org_mp3_fptr,int *content_size);

#endif
