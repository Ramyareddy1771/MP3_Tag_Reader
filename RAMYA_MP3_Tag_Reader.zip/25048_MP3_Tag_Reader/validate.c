#include "mp3_header.h"
#include  "mp3_view.h"
#include "mp3_edit.h"
#include"validate.h"
#include"ui.h"
#include<string.h>
#include<stdio.h>
void validate_cla(int argc, char *argv[], struct MP3 *mp3)
{
	if (argc <= 1)
    {
       printf(RED"No arguments provided\n"RESET);
        
    }
	else if( strcmp(argv[1], "--help") == 0 && argc == 2)
    {
		printf(BLUE"\n------------------------------->HELP<-----------------------------------------\n"RESET);
		printf(PINK"1. -v -> to view mp3 file contents\n"RESET);
		printf(PINK"2. -e -> to edit mp3 file contents\n"RESET);
		printf(YELLOW"\t\t2.1. -t -> to edit song title\n"RESET);
		printf(YELLOW"\t\t2.2. -a -> to edit artist name\n"RESET);
		printf(YELLOW"\t\t2.3. -A -> to edit album name\n"RESET);
		printf(YELLOW"\t\t2.4. -y -> to edit year\n"RESET);
		printf(YELLOW"\t\t2.5. -m -> to edit content\n"RESET);
		printf(YELLOW"\t\t2.6. -c -> to edit comment\n"RESET);
		printf(BLUE"------------------------------------------------------------------------------\n"RESET); 
    }
	else if (strcmp(argv[1], "-v") == 0 && argc == 3)
	{
		mp3->mp3_filename = argv[2];
		view(mp3, argc, argv);
	}
	else if (strcmp(argv[1], "-e") == 0 && argc == 5)//CHECK FOR EDIT ARGUMENT AND EDIT MP3 FILE CONTENTS
    {
		mp3->edit_option = argv[2];// -t / -a / -A / -y / -m / -c
		mp3->new_data = argv[3];// new data
		mp3->mp3_filename = argv[4];//mp3 file
		edit(mp3, argc, argv);
	}
	else
    {
		printf(RED"------------------------------------------------------------------------------\n"RESET);
		printf(RED"ERROR: ./a.out : INVALID ARGUMENTS\n"RESET);
		printf(YELLOW"USAGE : To view please pass like: ./a.out -v mp3filename\n"RESET);
		printf(YELLOW"To edit please pass like: ./a.out -e -t/-a/-A/-m/-y/-c changing_text mp3filename\n"RESET);
		printf(YELLOW"To get help pass like : ./a.out --help\n"RESET);
		printf(RED"------------------------------------------------------------------------------\n"RESET);
	}

}



