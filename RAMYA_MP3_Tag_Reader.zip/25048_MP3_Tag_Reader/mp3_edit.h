#ifndef mp3_edit_h
#define mp3_edit_h

#include"mp3_view.h"
//void edit(struct MP3 *mp3);
void edit(struct MP3 *mp3,int argc, char *argv[]);
#endif