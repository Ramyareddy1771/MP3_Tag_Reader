
#include "mp3_header.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"ui.h"
#include"mp3_view.h"
#include"mp3_edit.h"
#include"validate.h"

void edit(struct MP3 *mp3,int argc, char *argv[])
{

   char edit_tag[5];  

   // comparing each tag
   if(! strcmp(argv[2],"-t")) 
   {
      strcpy(edit_tag,"TIT2");
      printf(YELLOW "title is editing as %s\n" RESET,argv[3]);
      //edit_tag[4]='\0';
   }

   else if (! strcmp(argv[2],"-a"))
   {
      strcpy(edit_tag,"TPE1");
      printf(YELLOW "Artist Name is editing as %s\n" RESET,argv[3]);
      //edit_tag[4]='\0';
   }

   else if (! strcmp(argv[2],"-A"))
   {
      strcpy(edit_tag,"TALB");
       printf(YELLOW "Album is editing as %s\n" RESET,argv[3] );
      //edit_tag[4]='\0';
   }

   else if (! strcmp(argv[2],"-y"))
   {
      strcpy(edit_tag,"TYER");
      printf(YELLOW "Year is editing as %s\n" RESET,argv[3]);
      //edit_tag[4]='\0';
   }

   else if (! strcmp(argv[2],"-m"))
   {
      strcpy(edit_tag,"TCON");
      printf(YELLOW "content type is editing as %s\n" RESET,argv[3]);
      //edit_tag[4]='\0';
   }

   else if (! strcmp(argv[2],"-c"))
   {
      strcpy(edit_tag,"COMM");
      printf(YELLOW "comment is editing as %s\n" RESET,argv[3]);
      //edit_tag[4]='\0';
   }

   else
   {
      printf(RED"Invalid\n" RESET);
      return;
   }

   // size of updated string size + 1 for null character
   int new_size;                 
   new_size=strlen(argv[3])+1;
   
   // opening the file in read binary mode at the place of 4 index 
     mp3->org_mp3_fptr=fopen(argv[4],"rb"); 
      // opening the temp file in write binary mode          
     mp3->dup_mp3_fptr=fopen("temp.mp3","wb");      

    if( mp3->org_mp3_fptr== NULL)
    {
        perror(RED"Original file Error: \n" RESET);
        return ;
    }
    else if(mp3->dup_mp3_fptr == NULL)
    {
        perror(RED"duplicate file Error:\n" RESET);
        fclose(mp3->org_mp3_fptr);
        return ;
    }
    
      // taking the header and flag bytes
    char header[10]; char flag[2],encoding;              
    int old_size;                                 

    // reading 10 bytes from original and last bit should be '\0'
    fread(header,10,1,mp3->org_mp3_fptr);       
    //header[10]='\0';                
     // write 10 bytes to the temp file           
    fwrite(header,10,1,mp3->dup_mp3_fptr);      
    char tag[5];                                 
    for(int i=0; i<6; i++)// all the 6 tags 
    {        
        /* reading for tags from original file */
    fread(tag,4,1,mp3->org_mp3_fptr);
    
    tag[4]='\0';
    /* write tag */
      fwrite(tag,4,1,mp3->dup_mp3_fptr);

      /* read old size */
      fread(&old_size,4,1,mp3->org_mp3_fptr);

      int temp_size = old_size;

      /* write same old size */
      fwrite(&temp_size,4,1,mp3->dup_mp3_fptr);

      /* convert old size */
      toggle_endianess(mp3,&old_size);

      /* read and write flags */
      fread(flag,2,1,mp3->org_mp3_fptr);

      fwrite(flag,2,1,mp3->dup_mp3_fptr);

      /* read and write encoding */
      fread(&encoding,1,1,mp3->org_mp3_fptr);

      fwrite(&encoding,1,1,mp3->dup_mp3_fptr);

      if(strcmp(edit_tag,tag) != 0)
      {
         char content[old_size - 1];

         fread(content,old_size - 1,1,mp3->org_mp3_fptr);

         fwrite(content,old_size - 1,1,mp3->dup_mp3_fptr);
      }

      else
      {
         /* skip old content */
         fseek(mp3->org_mp3_fptr,old_size - 1,SEEK_CUR);

         /* write updated data */
         fwrite(argv[3],strlen(argv[3]),1,mp3->dup_mp3_fptr);

         /* padding remaining bytes */
         char ch = '\0';

         for(int j = 0; j < (old_size - 1) - strlen(argv[3]); j++)
         {
            fwrite(&ch,1,1,mp3->dup_mp3_fptr);
         }

         /* copy remaining data */
         while(fread(&ch,1,1,mp3->org_mp3_fptr) == 1)
         {
            fwrite(&ch,1,1,mp3->dup_mp3_fptr);
         }

         printf(GREEN "Tag %s is updated successfully\n" RESET,edit_tag);

         break;
      }
   }

   fclose(mp3->org_mp3_fptr);
   fclose(mp3->dup_mp3_fptr);
   
   /*remove original file */
   remove(argv[4]);
   /* rename temp file to original file */
   rename("temp.mp3",argv[4]);
}