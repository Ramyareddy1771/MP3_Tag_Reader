#include "mp3_header.h"
#include<stdio.h>
#include"ui.h"
#include"validate.h"
int main(int argc, char *argv[])
{
    /* structure variable declaration */
    struct MP3 mp3;
    
    validate_cla(argc,argv,&mp3);
 
    mp3.mp3_filename="sample.mp3";

    return 0;

}
